document.getElementById("input-button").focus();
function changeiconss() {
  window.open("b2brain.html", "_self");
  // alert("Hello");
}
function account() {
    var dis = document.getElementById("acc-content");
    dis.classList.toggle("show");
}

function preference() {
    var dis = document.getElementById("pre-content");
    dis.classList.toggle("show");
}

function clickclr() {
  var a=document.getElementById("colorchange");
  a.style.color="green";
  a.innerHTML="Tracking";
  a.style.border="1px solid green";
}  

fetch('https://staging.staging.b2brain.com/search/autocomplete_org_all/?q=<search-term>').then((data)=>{
        // console.log(data);
        return data.json();
       }).then((completedata)=>{
            // console.log(completedata[2].slug);
            let data1="";
            completedata.map((values)=>{
                data1+=` <div class="col-6">
            <div class="row">
                      <div class="col">
                        <img src="${values.logo}" alt="Error">
                      </div>
                      <div class="col">
                      <h3>${values.company}</h3>
                        <p>${values.website}</p>
                      </div>
                      <div class="col">
                      <button id="colorchange" onclick="clickclr()">Track</button>
                      </div>
            </div>
            </div>`});
        document.getElementById("cards").innerHTML=data1;

       }).catch((err)=>{console.log(err)})