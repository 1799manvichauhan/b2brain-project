function account()
        {
            var dis = document.getElementById("acc-content");
            dis.classList.toggle("show");
        }
        function preference()
        {
            var dis = document.getElementById("pre-content");
            dis.classList.toggle("show");
        }
function changeicon(){
    window.open("b2brainsearch.html","_self");
}